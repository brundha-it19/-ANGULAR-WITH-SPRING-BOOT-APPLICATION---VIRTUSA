In this project we will be developing a full stack application using Spring Boot
and Angular 7<br>

Complete explanation can be found at - https://www.javainuse.com/spring/ang7-hello

[![Watch the video](https://www.javainuse.com/ang2-you.JPG)](https://youtu.be/CCOLXL-hOfQ)
